﻿namespace KPreisser.UI
{
    /// <summary>
    /// 
    /// </summary>
    public enum TaskDialogStartupLocation
    {
        /// <summary>
        /// 
        /// </summary>
        CenterScreen = 0,

        /// <summary>
        /// 
        /// </summary>
        CenterParent = 1
    }
}
